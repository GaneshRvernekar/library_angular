export interface stud{
  name:string,
  usn:string,
  email:string,
  dep:string,
  gender:string,
  book:string
}

export interface book{

  name:string,
  description:string,
  available:boolean,
  student:string
}
